package com.tomgregory;

import org.junit.jupiter.api.Test;

public class ApplicationTest {
    @Test
    public void canRunApplication() {
        Application.main(new String[]{});
    }
}
