package com.tomgregory;

public class Application {
    public static void main(String[] args) {
        System.out.println("Gradle GitHub actions 4tw!");
    }
}
